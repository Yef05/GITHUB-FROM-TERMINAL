#!/bin/bash
#SBATCH -p normal #Particion (cola)
#SBATCH -N 1 # Numero de nodos
#SBATCH -n 10 # Numero de nucleos
#SBATCH -t 00-00:20 # limite de tiempo (D-HH:MM)
#SBATCH -o salida.out # Salida STDOUT
#SBATCH -e error.err # Salida STDERR
#SBATCH --mail-user=yeferson.torres@urosario.edu.co #Direccion e-mail a donde notificar el estado del trabajo
#SBATCH --mail-type=ALL	#Especifica que eventos notificar al correo (ALL, BEGIN, END, REQUEUE, FAIL)

module load muscle/3.8.31
muscle -in aliconcat.fasta -out misticetos_muscle.fasta

